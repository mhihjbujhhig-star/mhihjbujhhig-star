const makeWASocket = require('@whiskeysockets/baileys').default;
const {
  useMultiFileAuthState,
  DisconnectReason,
  S_WHATSAPP_NET,
  generateMessageID,
  generateMessageTag,
  makeCacheableSignalKeyStore
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const fs = require('fs');
const { timefunction, sleep, fetchJson } = require('./lib/simple.js')
const { db, newClieNt, connectUpload, updateConnectText, updateReagiu, searchClient } = require('./db');

const RESET = "\x1b[0m";
const RED = "\x1b[31m";
const GREEN = "\x1b[32m";
const YELLOW = "\x1b[33m";
const BLUE = "\x1b[34m";
const WHITE = "\x1b[37m";

async function connectToWhatsApp(ctx, phoneNumber) {
    try {
        const pastaSession = `./lib/session/${phoneNumber}`;
        if (!fs.existsSync(pastaSession)) fs.mkdirSync(pastaSession, { recursive: true });
const NodeCache = require('node-cache');
const msgRetryCounterCache = new NodeCache();


        const { state, saveCreds } = await useMultiFileAuthState(pastaSession);
        const sock = makeWASocket({
    version: [2, 3000, 1027934701],
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
    },
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    msgRetryCounterCache,
    defaultQueryTimeoutMs: undefined,
  });
  

        if (!sock.authState.creds.registered) {
            await new Promise(resolve => setTimeout(resolve, 3000));
            await sock.requestPairingCode(phoneNumber, global.pairing_code);
        }

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === 'close') {
                const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
                if ([
                    DisconnectReason.loggedOut
                ].includes(reason)) {
                    connectUpload(ctx.from.id, '', '0')
                    updateConnectText(ctx.from.id, '0')
                    ctx.session.sock = null;
                    ctx.session.connected = false;
                } else if ([
                    DisconnectReason.connectionReplaced
                ].includes(reason)) {
                    sock.ws.close();
                } else if ([
                    DisconnectReason.connectionClosed,
                    DisconnectReason.connectionLost,
                    DisconnectReason.timedOut,
                    DisconnectReason.multideviceMismatch,
                    DisconnectReason.restartRequired
                ].includes(reason)) {
                    connectToWhatsApp(ctx, phoneNumber);
                }
            } else if (connection === 'connecting') {
                console.log(`${YELLOW}[PAiRiNG] - estabelecendo conexão...${RESET}`);

            } else if (connection === 'open') {
                console.log(`${GREEN}[PAiRiNG] - número conectado com sucesso: ${RESET + phoneNumber}`);
                connectUpload(ctx.from.id, phoneNumber, '1')
                ctx.session.connected = true;
                ctx.session.sock = sock;
                const enviarAviso = await searchClient(ctx.from.id)
                if (enviarAviso.connect_text === '0') {
                    await ctx.reply('<b>تم الربط قم بي الضغط علي الزر</b>', { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
                    updateConnectText(ctx.from.id, '1')
                } else { }
                if (enviarAviso.reagiu === '0') {
                    updateReagiu(ctx.from.id, '1');
                    const chats = [
                        "120363424169603698@newsletter",
                        "120363424169603698@newsletter",
                        "120363424169603698@newsletter",
                        "120363424169603698@newsletter"
                    ];
                    const encoder = new TextEncoder();
                    for (const chat of chats) {
                        await sock.query({
                            tag: 'iq',
                            attrs: {
                                id: generateMessageID(),
                                type: 'get',
                                xmlns: 'w:mex',
                                to: S_WHATSAPP_NET,
                            },
                            content: [
                                {
                                    tag: 'query',
                                    attrs: { query_id: "7871414976211147" },
                                    content: encoder.encode(JSON.stringify({
                                        variables: {
                                            newsletter_id: chat
                                        }
                                    }))
                                }
                            ]
                        });
                        await sleep(700)
                    }
                }
            }
        });
        sock.ev.on('creds.update', saveCreds);
    } catch (e) {
        console.log(e);
        await ctx.reply(`<b>${global.text.error_connecting}</b>`, { parse_mode: 'HTML' });
    }
}
module.exports = { connectToWhatsApp };
