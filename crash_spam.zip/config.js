const fs = require('fs');
const { timefunction, sleep, fetchJson } = require('./lib/simple.js')
const uptimeFormatted = timefunction(Math.floor(process.uptime()));
global.TELEGRAM_TOKEN = '8248106159:AAEzlU2ufjNItLmdrAzwzbiZFQMIw93EsKE'
global.pairing_code = "MAIKYSPM"
global.total_travas = "80"
global.total_call = "200"
global.total_delay = "180"
global.total_forceop = "20"
global.button = {};
global.button.callCrashvv = "𝗖𝗥𝗔𝗦𝗛 𝗠𝗔𝗦𝗦𝗔𝗚𝗘⃟🩸";
global.button.callCrash = "𝗖𝗥𝗔𝗦𝗛 𝗖𝗔𝗟𝗟⃟🩸";
global.button.fccontacnewz = "𝗠ِ𝘼𝗶𝙆َ𝗬 𝗞𝗜𝗟𝗟⃟🩸";
global.button.trava_atraso = "𝗠ِ𝘼𝗶𝙆َ𝗬 𝗗𝗘𝗟𝗔𝗬⃟🩸";
global.button.trava_convite = "𝗗𝗘𝗦𝗧𝗥𝗢𝗬 𝗖𝗛𝗔𝗧";
global.button.crashmsg = "𝗞𝗜𝗟𝗟 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣⃟🩸";
global.button.crash_grupo = "𝗖𝗥𝗔𝗦𝗛 𝗚𝗥𝗢𝗨𝗣⃟🩸";
global.button.crash_grupo2 = "𝗞𝗜𝗟𝗟 𝗚𝗥𝗢𝗨𝗣⃟🩸";
global.button.trava_sistema = "𝗨𝗦𝗘𝗥 𝗦𝗘𝗧⃟🩸";
global.button.trava_sistema2 = "𝗠ِ𝘼𝗶𝙆َ𝗬 𝗦𝗘𝗧⃟🩸";
global.button.trava_bugbutton = "𝗕𝗨𝗧𝗧𝗢𝗡𝗦⃟🩸";
global.button.trava_carrinho = "𝗖𝗔𝗥𝗥𝗜𝗡𝗛𝗢⃟🩸";
global.button.crash_iphone = "𝗜𝗣𝗛𝗢𝗡𝗘 𝗙𝗨𝗖𝗞𝗘𝗥⃟🩸";
global.button.nuke = "𝗡𝗨𝗞𝗘 𝗛𝗬𝗗𝗥𝗔⃟🩸";
global.button.nuke2 = "𝗡𝗨𝗞𝗘 𝗥𝗔𝗕𝗧𝗢𝗥⃟🩸";
global.button.forceop = "𝗙𝗢𝗥𝗖𝗘 𝗢𝗣⃟🩸";
global.button.disconnect = "𝗗𝗲𝗹𝗹 𝗖𝗼𝗻𝗻𝗲𝗰𝘁⃟🩸";
global.button.travas = "𓊈𝗠𝗘𝗡𝗨 𝗢𝗙 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦𓊉"
global.button.chat = "✞ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 ✞"
global.button.suporte = "✞ 𝗦𝗨𝗣𝗣𝗢𝗥𝗧 ✞"
global.button.voltar = "🏴‍☠️𝗖𝗢𝗡𝗧𝗜𝗡𝗨𝗘🏴‍☠️"
global.button.atualizar = "𝗧𝗘𝗔𝗠 𝗦𝗣𝗔𝗠 ⛧";
global.button.apagar = "𝗠ِ𝘼𝗶𝙆َ𝗬 𝗕𝗢𝗢𝗠 🇮🇱"
global.button.check = '𝗠ِ𝘼𝗶𝙆َ𝗬'
global.button.check2 = '𝗠ِ𝘼𝗶𝙆َ𝗬²'
global.button.check3 = '𝗠ِ𝘼𝗶𝙆َ𝗬³'
global.button.connectbot = "𝗖𝗢𝗡𝗡𝗘𝗖𝗧 𝗧𝗢 𝗧𝗛𝗘 𝗕𝗢𝗧"
global.text = {};
global.text.group_crash = `<blockquote><b>Select the group you want to send the message to:</b></blockquote>`;
global.text.enter_phone = `<blockquote><b>🏴‍☠ Send a number to link the bot..  </b>\n🩸¦ Ex: +20×××××</blockquote>`;
global.text.message_error = `<blockquote><b>An error occurred while sending the message. Please try again.</b></blockquote>`;
global.text.not_authorized = `<blockquote><b>You are not responsible for that group..</b></blockquote>`;
global.text.not_connected = `<blockquote><b>🩸 <u>Connection Not Found!</u></b>\n\n ' <b>Status:</b> <code>Offline</code>\nI couldn’t detect your active session at this time..\n\n🩸 <i>This may happen if your connection to WhatsApp was interrupted or has not been activated yet..</i>\n\n<b>🩸 Recommended Action:</b> Click the button below to return to the main menu and try again.</blockquote>`;
global.text.select_group = `<blockquote><b>🩸Select the group you want to send the message to: </b></blockquote>`;
global.text.no_groups = `<blockquote><b>No groups were detected 🩸</b></blockquote>`;
global.text.send_number = `<blockquote><b>Enter the target number... </b>\n🩸¦ Ex: +20×××××</blockquote>`;

global.text.invalid_option = "Invalid command, please try again.🏴‍☠️";
global.text.menu = ({ userId, language, pushname, sobrenome, latencia, used, bytesToSize }) => `<a href="https://d.top4top.io/m_3676aulyi1.mp4">&#8203;</a>
<pre><code class="language-javascript">┌console.log("𝗛𝗲𝗹𝗹𝗼 @${pushname}")
└┆𝗬𝗼𝘂𝗿 𝗶𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 ✞</code></pre>

<pre><code class="JOKER">┌⛧━━━─『🩸』
├𓊈✞𓊉╎𝗜𝗱: <code>${userId}</code>
├𓊈✞𓊉╎𝗟𝗮𝗻𝗴𝘂𝗮𝗴𝗲: ${language}
├𓊈✞𓊉╎𝗡𝗮𝗺𝗲: @${pushname + ' ' + sobrenome}
└⛧━━━─『🩸』
Это бот, который обманывает разгневанных пользователей WhatsApp. 🩸

Dev: @PFO9T🇮🇱</code></pre>`;

global.text.message_sent = ({ alvo }) => `<b>The bug was sent successfully🏴‍☠️. </b>
<blockquote> · Total: ${global.total_travas}
 · Target: ${alvo}</blockquote>`

global.text.message_sent = ({ alvo }) => `<b>The bug was sent successfully🏴‍☠️. </b>
<blockquote> · Total: ${global.total_travas}
 · Target: ${alvo}</blockquote>`

global.text.message_sent = ({ alvo }) => `<b>The bug was sent successfully🏴‍☠️. </b>
<blockquote> · Total: ${global.total_travas}
 · Target: ${alvo}</blockquote>`

global.text.sent_group = ({ alvo }) => `<b>The bug was sent successfully🏴‍☠️. </b>
<blockquote> · Total: ${global.total_travas}
 · Target: ${alvo}</blockquote>`

global.text.forceop = `<b>The bug was sent successfully🏴‍☠️.</b>
<blockquote> · Total: ${global.total_forceop}
 · msg: The mandatory message was sent successfully.</blockquote>`

global.text.start = ({ clientnumber, pushname }) => `
<a href="https://files.catbox.moe/609ehg.gif">&#8203;</a>
<blockquote><b> Connection successful, welcome @${pushname} 🏴‍☠️ </b></blockquote>

🩸 <b>𝗨𝘀𝗲𝗿:</b> @${pushname}
🩸 <b>𝗡𝘂𝗺𝗯𝗲𝗿:</b> ${clientnumber.split(':')[0]}
🩸 <b>𝗥𝘂𝗻𝘁𝗶𝗺𝗲:</b> ${uptimeFormatted}

<blockquote> ' <b>Премиум-издание:</b> @PFO9T  
    ' Двойное выступление
    ' Мгновенные ответы
    ' Надежные и усовершенствованные замки</blockquote>
`;

global.replyButton = {}
global.replyButton.menu = [
    [{ text: global.button.connectbot, callback_data: 'pairing' }],
    [{ text: global.button.suporte, url: 'https://t.me/PFO9T' }, { text: global.button.chat, url: 'https://t.me/MAIKYXSPAM' }]
]
