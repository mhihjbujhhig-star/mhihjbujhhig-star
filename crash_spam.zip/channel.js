const { Telegraf } = require('telegraf');

const bot = new Telegraf('8248106159:AAEzlU2ufjNItLmdrAzwzbiZFQMIw93EsKE');
const requiredChannels = ['@PFO9T', '@PFO9T'];

async function checkMember(fromId) {
    try {
        for (const channel of requiredChannels) {
            const chatMember = await bot.telegram.getChatMember(channel, fromId);
            if (!['member', 'administrator', 'creator'].includes(chatMember.status)) {
                return false;
            } else {
            }
        }
        return true;
    } catch (e) {
        return false;
    }
}

bot.launch()
    .then(() => {
        console.log('Bot iniciado!');
    })
    .catch((err) => {
        console.error('Erro ao iniciar o bot:', err);
    });

module.exports = { checkMember };
