const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, './lib/db/clientes.db');
const dbExists = fs.existsSync(dbPath);
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Erro ao abrir o banco de dados:', err.message);
    } else {
        console.log('Conectado ao banco de dados clientes.db');
    }
});

if (!dbExists) {
    db.serialize(() => {
        db.run(`CREATE TABLE IF NOT EXISTS clientes (
                nick TEXT,
                from_id TEXT,
                data TEXT,
                hora TEXT,
                numero TEXT,
                conectado TEXT,
                connect_text TEXT,
                reagiu TEXT
            )`, (err) => {
            if (err) {
                console.error('Erro ao criar tabela clientes:', err.message);
            } else {
            }
        });
    });
}

async function newClieNt(nick, from, data, hora, numero, conectado, connect_text, reagiu) {
    try {
        const existingClient = await new Promise((resolve, reject) => {
            db.get(`SELECT * FROM clientes WHERE from_id = ?`, [from], (err, row) => {
                if (err) {
                    console.error('Erro ao consultar cliente:', err.message);
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });
        if (existingClient) {
        } else {
            db.run(`
                INSERT INTO clientes (nick, from_id, data, hora, numero, conectado, connect_text, reagiu)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `, [nick, from, data, hora, numero, conectado, connect_text, reagiu], (err) => {
                if (err) {
                    console.error('Erro ao inserir novo cliente:', err.message);
                } else {
                }
            });
        }
    } catch (error) {
        console.error('Erro na função newClieNt:', error);
    }
}

function connectUpload(from_id, numero, conectado) {
    db.run(`
        UPDATE clientes
        SET numero = ?, conectado = ?
        WHERE from_id = ?`, [numero, conectado, from_id], (err) => {
            if (err) {
            console.error('Erro ao atualizar numero e conectado:', err.message);
        } else {
        }
    });
}
function updateConnectText(from_id, connect_text) {
    db.run(`
        UPDATE clientes
        SET connect_text = ?
        WHERE from_id = ?
    `, [connect_text, from_id], (err) => {
        if (err) {
            console.error('Erro ao atualizar connect_text:', err.message);
        } else {
        }
    });
}

function updateReagiu(from_id, reagiu) {
    db.run(`UPDATE clientes
        SET reagiu = ?
        WHERE from_id = ?
    `, [reagiu, from_id], (err) => {
        if (err) {
            console.error('Erro ao atualizar reagiu:', err.message);
        } else {
        }
    });
}

function searchClient(from_id) {
    return new Promise((resolve, reject) => {
        db.get(`
            SELECT * FROM clientes
            WHERE from_id = ?
        `, [from_id], (err, row) => {
            if (err) {
                console.error('Erro ao consultar cliente:', err.message);
                return reject(err);
            }
            if (row) {
                resolve(row);
            } else {
                resolve(null);
            }
        });
    });
}
function getAllClients() {
    return new Promise((resolve, reject) => {
        db.all(`SELECT * FROM clientes`, (err, rows) => {
            if (err) {
                console.error('Erro ao buscar clientes:', err.message);
                return reject(err);
            }
            resolve(rows);
        });
    });
}
async function resetAllClients() {
    try {
        const clientes = await getAllClients();
        for (const cliente of clientes) {
            await new Promise((resolve, reject) => {
                db.run(`
                    UPDATE clientes
                    SET
                        numero = '',
                        conectado = '0',
                        connect_text = '0',
                        reagiu = '0'
                    WHERE from_id = ?
                `, [cliente.from_id], function (err) {
                    if (err) {
                        console.error(`Erro ao resetar cliente ${cliente.nick} (${cliente.from_id}):`, err.message);
                        return reject(err);
                    }
                    console.log(`Cliente resetado: ${cliente.nick} (${cliente.from_id})`);
                    resolve();
                });
            });
        }
        console.log(`\nTodos os clientes foram resetados com sucesso.`);
    } catch (err) {
        console.error('Erro ao resetar todos os clientes:', err);
    }
}
module.exports = { db, newClieNt, connectUpload, updateConnectText, updateReagiu, searchClient, getAllClients, resetAllClients };
