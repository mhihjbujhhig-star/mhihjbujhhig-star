const fs = require('fs');
const path = require('path');

const RED = '\x1b[31m';
const GREEN = '\x1b[32m';
const RESET = '\x1b[0m';
function limparArquivosSession() {
    const sessionPath = path.join(__dirname, 'lib', 'session');
    if (!fs.existsSync(sessionPath)) {
        console.log(`${RED}❌ Pasta ./lib/session não encontrada.${RESET}`);
        return;
    }
    const pastas = fs.readdirSync(sessionPath, { withFileTypes: true })
        .filter(item => item.isDirectory());
    pastas.forEach(pasta => {
        const pastaPath = path.join(sessionPath, pasta.name);
        const arquivosNaPasta = fs.readdirSync(pastaPath);
        arquivosNaPasta.forEach(arquivo => {
            if (arquivo === 'creds.json') return;
            const arquivoPath = path.join(pastaPath, arquivo);
            if (!fs.existsSync(arquivoPath) || fs.statSync(arquivoPath).isDirectory()) return;
            try {
                const stats = fs.statSync(arquivoPath);
                const agora = new Date();
                const idadeMs = agora - stats.birthtime;
                const idadeMin = idadeMs / 1000 / 60;
                if (idadeMin > 1440) {
                    fs.unlinkSync(arquivoPath);
                    console.log(`${RED}🗑️ Apagado: ${arquivoPath} (idade: ${(idadeMin / 60).toFixed(1)} h)${RESET}`);
                }
            } catch (err) {
                console.error(`${RED}⚠️ Erro ao processar ${arquivoPath}:${RESET}`, err);
            }
        });
    });
}
module.exports = { limparArquivosSession };
